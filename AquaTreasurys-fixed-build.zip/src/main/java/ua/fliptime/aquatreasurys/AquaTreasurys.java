package ua.fliptime.aquatreasurys;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.*;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.world.World;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class AquaTreasurys extends JavaPlugin implements Listener, TabExecutor {
    private final Map<String, Treasury> treasuries = new LinkedHashMap<>();
    private final Map<String, String> blockIndex = new HashMap<>();
    private final Set<String> openedChests = new HashSet<>();
    private final Set<String> unlockedChests = new HashSet<>();
    private BukkitTask generationTask;
    private File dataFile;

    @Override public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();
        new File(getDataFolder(), "schematics").mkdirs();
        dataFile = new File(getDataFolder(), "treasuries.yml");
        loadData();
        Objects.requireNonNull(getCommand("aquatreasurys")).setExecutor(this);
        getCommand("aquatreasurys").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getConfig().getBoolean("generation.enabled")) startGeneration();
        getLogger().info("AquaTreasurys enabled.");
    }
    @Override public void onDisable() {
        if (generationTask != null) generationTask.cancel();
        saveData();
    }

    private String key(Location l) { return l.getWorld().getName()+":"+l.getBlockX()+":"+l.getBlockY()+":"+l.getBlockZ(); }
    private Location parseLoc(String s) {
        String[] p=s.split(":"); if(p.length!=4) return null;
        World w=BukkitAdapter.adapt(Bukkit.getWorld(p[0]));
        org.bukkit.World bw=Bukkit.getWorld(p[0]); if(bw==null)return null;
        return new Location(bw,Integer.parseInt(p[1]),Integer.parseInt(p[2]),Integer.parseInt(p[3]));
    }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&',s); }
    private void msg(CommandSender s,String m){s.sendMessage(color("&b[AquaTreasurys] &f"+m));}
    private boolean admin(CommandSender s){if(s.hasPermission("aquatreasurys.admin"))return true;msg(s,"Недостатньо прав.");return false;}

    private void startGeneration() {
        long ticks=Math.max(20,getConfig().getLong("generation.interval-seconds",1800)*20);
        generationTask=Bukkit.getScheduler().runTaskTimer(this,()->{
            int max=getConfig().getInt("generation.max-treasuries",5);
            if(treasuries.size()<max) generate(null);
        },ticks,ticks);
    }

    private boolean generate(CommandSender sender) {
        String worldName=getConfig().getString("generation.world","world");
        org.bukkit.World bw=Bukkit.getWorld(worldName);
        if(bw==null){if(sender!=null)msg(sender,"Світ не знайдено: "+worldName);return false;}
        String schemName=getConfig().getString("generation.schematic","treasure.schem");
        File f=new File(new File(getDataFolder(),"schematics"),schemName);
        if(!f.exists()){if(sender!=null)msg(sender,"Схематика не знайдена: "+f.getPath());return false;}
        int attempts=getConfig().getInt("generation.attempts-per-treasury",80);
        for(int i=0;i<attempts;i++){
            int x=rand(getConfig().getInt("generation.min-x",-5000),getConfig().getInt("generation.max-x",5000));
            int z=rand(getConfig().getInt("generation.min-z",-5000),getConfig().getInt("generation.max-z",5000));
            int y=rand(getConfig().getInt("generation.min-y",50),getConfig().getInt("generation.max-y",110));
            Location loc=new Location(bw,x,y,z);
            if(!bw.isChunkLoaded(x>>4,z>>4)) bw.getChunkAt(x>>4,z>>4).load();
            if(getConfig().getBoolean("generation.require-solid-ground") && !bw.getBlockAt(x,y-1,z).getType().isSolid())continue;
            if(!farEnough(loc))continue;
            if(pasteSchematic(f,loc,sender))return true;
        }
        if(sender!=null)msg(sender,"Не вдалося знайти підходящу локацію.");
        return false;
    }
    private int rand(int a,int b){if(a>b){int t=a;a=b;b=t;}return ThreadLocalRandom.current().nextInt(a,b+1);}
    private boolean farEnough(Location l){
        double d=getConfig().getDouble("generation.min-distance-between-treasuries",500);
        for(Treasury t:treasuries.values())if(t.origin.getWorld().equals(l.getWorld())&&t.origin.distanceSquared(l)<d*d)return false;
        return true;
    }
    private boolean pasteSchematic(File file,Location loc,CommandSender sender){
        try(InputStream in=Files.newInputStream(file); ClipboardReader reader=ClipboardFormats.findByFile(file).getReader(in)){
            Clipboard clipboard=reader.read();
            World weWorld=BukkitAdapter.adapt(loc.getWorld());
            BlockVector3 origin=BlockVector3.at(loc.getBlockX(),loc.getBlockY(),loc.getBlockZ());
            try(EditSession session=WorldEdit.getInstance().newEditSession(weWorld)){
                new ClipboardHolder(clipboard).createPaste(session).to(origin)
                    .ignoreAirBlocks(!getConfig().getBoolean("generation.paste-air",false))
                    .copyEntities(getConfig().getBoolean("generation.paste-entities",false))
                    .copyBiomes(getConfig().getBoolean("generation.paste-biomes",false)).build().complete();
            }
            String id=UUID.randomUUID().toString().substring(0,8);
            Treasury t=new Treasury(id,loc,clipboard.getRegion().getWidth(),clipboard.getRegion().getHeight(),clipboard.getRegion().getLength());
            // WorldEdit paste origin corresponds to clipboard origin; save clipboard origin offset for accurate bounds.
            BlockVector3 min=clipboard.getRegion().getMinimumPoint();
            t.min=new Location(loc.getWorld(),loc.getBlockX()+min.getBlockX()-clipboard.getOrigin().getBlockX(),
                    loc.getBlockY()+min.getBlockY()-clipboard.getOrigin().getBlockY(),
                    loc.getBlockZ()+min.getBlockZ()-clipboard.getOrigin().getBlockZ());
            scanTreasury(t);
            treasuries.put(id,t); saveData();
            if(sender!=null)msg(sender,"Скарбницю створено: "+id);
            return true;
        }catch(Exception ex){getLogger().warning("Schematic paste failed: "+ex.getMessage());if(sender!=null)msg(sender,"Помилка вставки схематики. Перевір файл .schem.");return false;}
    }
    private void scanTreasury(Treasury t){
        t.protection.clear();t.chests.clear();
        Set<String> protect=new HashSet<>(getConfig().getStringList("treasury.protection-blocks"));
        Set<String> chestNames=new HashSet<>(getConfig().getStringList("treasury.loot-chest-names"));
        for(int x=0;x<t.width;x++)for(int y=0;y<t.height;y++)for(int z=0;z<t.length;z++){
            Block b=t.min.getWorld().getBlockAt(t.min.getBlockX()+x,t.min.getBlockY()+y,t.min.getBlockZ()+z);
            if(protect.contains(b.getType().getKey().toString()))t.protection.add(key(b.getLocation()));
            if(b.getState() instanceof Container c && c.getCustomName()!=null && chestNames.contains(ChatColor.stripColor(c.getCustomName()))){
                t.chests.add(key(b.getLocation()));
            }
        }
        t.remaining=t.protection.size();
        t.unlocked=t.remaining==0;
        for(String k:t.protection)blockIndex.put(k,t.id);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onTntPrime(BlockPlaceEvent e){
        if(e.getBlockPlaced().getType()!=Material.TNT)return;
        // TNT placement itself is allowed. Explosion event controls damage to protected blocks.
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onExplosion(EntityExplodeEvent e){
        Entity entity=e.getEntity();
        if(!(entity instanceof TNTPrimed))return;
        List<Block> affected=new ArrayList<>(e.blockList());
        for(Block b:affected){
            String k=key(b.getLocation());String id=blockIndex.get(k);
            if(id==null)continue;
            Treasury t=treasuries.get(id);
            if(t==null){blockIndex.remove(k);continue;}
            if(t.protection.contains(k)){
                t.protection.remove(k);blockIndex.remove(k);
                b.setType(Material.AIR,false);
                t.remaining=Math.max(0,t.protection.size());
                if(t.remaining==0)unlock(t);
                announceProgress(t);
            }
        }
        // Keep TNT from damaging unrelated blocks; only registered protection blocks are affected.
        e.blockList().removeIf(b->!blockIndex.containsKey(key(b.getLocation())));
        e.setYield(0f);
    }
    private void announceProgress(Treasury t){
        for(Player p:Bukkit.getOnlinePlayers())if(p.getWorld().equals(t.origin.getWorld())&&p.getLocation().distanceSquared(t.origin)<100*100){
            String text=color(getConfig().getString("treasury.announce.actionbar","&bProtection: &f%remaining%")
                    .replace("%remaining%",String.valueOf(t.remaining)).replace("%name%",getConfig().getString("treasury.name","Treasury")));
            p.sendActionBar(text);
        }
        saveData();
    }
    private void unlock(Treasury t){
        t.unlocked=true;
        for(String chestKey:t.chests){
            Location l=parseLoc(chestKey);if(l==null)continue;
            Block b=l.getBlock();
            if(b.getState() instanceof Container c){
                c.setCustomName(null);c.update();
                // Mark unlocked in memory; opening listener allows it.
                unlockedChests.add(chestKey);
            }
        }
        for(Player p:Bukkit.getOnlinePlayers())if(p.getWorld().equals(t.origin.getWorld())&&p.getLocation().distanceSquared(t.origin)<100*100){
            p.sendMessage(color(getConfig().getString("treasury.announce.chat","&aTreasury unlocked!").replace("%name%",getConfig().getString("treasury.name","Treasury"))));
            p.playSound(p.getLocation(),Sound.UI_TOAST_CHALLENGE_COMPLETE,1,1);
        }
        saveData();
    }
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onChestOpen(InventoryOpenEvent e){
        if(!(e.getPlayer() instanceof Player p))return;
        Inventory inv=e.getInventory();
        if(!(inv.getHolder() instanceof BlockState holder))return;
        String k=key(holder.getBlock().getLocation());
        for(Treasury t:treasuries.values())if(t.chests.contains(k)){
            if(!t.unlocked){
                e.setCancelled(true);p.sendMessage(color("&cСкарбниця ще захищена! Знищ захисні блоки TNT."));
            } else {
                // Apply configured loot once on first opening.
                if(!openedChests.contains(k)){fillLoot(holder.getBlock(),t);openedChests.add(k);saveData();}
            }
            return;
        }
    }
    private void fillLoot(Block b,Treasury t){
        if(!(b.getState() instanceof Container c))return;
        c.getInventory().clear();
        ConfigurationSection sec=getConfig().getConfigurationSection("loot.default");
        if(sec==null)return;
        int rolls=sec.getInt("rolls",3);
        List<Map<?,?>> entries=sec.getMapList("entries");
        for(int r=0;r<rolls;r++){
            int total=0;for(Map<?,?> m:entries)total+=Math.max(0,((Number)m.getOrDefault("weight",1)).intValue());
            if(total<=0)break;
            int n=ThreadLocalRandom.current().nextInt(total),chosen=0;Map<?,?> selected=null;
            for(Map<?,?> m:entries){chosen+=Math.max(0,((Number)m.getOrDefault("weight",1)).intValue());if(n<chosen){selected=m;break;}}
            if(selected==null)continue;
            Material mat=Material.matchMaterial(String.valueOf(selected.get("material")));if(mat==null)continue;
            int min=((Number)selected.getOrDefault("min",1)).intValue(),max=((Number)selected.getOrDefault("max",1)).intValue();
            int amount=rand(min,max);ItemStack item=new ItemStack(mat,Math.max(1,Math.min(amount,mat.getMaxStackSize())));
            c.getInventory().addItem(item);
        }
        c.update();
    }

    private void restore(Treasury t){
        // Region restoration requires a block snapshot. Current version tracks bounds and removes schematic blocks,
        // but does not overwrite terrain because original-world snapshots are not stored yet.
        for(int x=0;x<t.width;x++)for(int y=0;y<t.height;y++)for(int z=0;z<t.length;z++){
            Block b=t.min.getWorld().getBlockAt(t.min.getBlockX()+x,t.min.getBlockY()+y,t.min.getBlockZ()+z);
            b.setType(Material.AIR,false);
        }
    }
    private void removeTreasury(String id,boolean restore){
        Treasury t=treasuries.remove(id);if(t==null)return;
        for(String k:t.protection)blockIndex.remove(k);
        for(String k:t.chests){openedChests.remove(k);unlockedChests.remove(k);}
        if(restore && getConfig().getBoolean("cleanup.restore-on-remove",true))restore(t);
        saveData();
    }
    private void saveData(){
        YamlConfiguration y=new YamlConfiguration();
        for(Treasury t:treasuries.values()){
            String p="treasuries."+t.id;
            y.set(p+".world",t.origin.getWorld().getName());y.set(p+".x",t.origin.getBlockX());y.set(p+".y",t.origin.getBlockY());y.set(p+".z",t.origin.getBlockZ());
            y.set(p+".minx",t.min.getBlockX());y.set(p+".miny",t.min.getBlockY());y.set(p+".minz",t.min.getBlockZ());
            y.set(p+".width",t.width);y.set(p+".height",t.height);y.set(p+".length",t.length);y.set(p+".remaining",t.remaining);y.set(p+".unlocked",t.unlocked);
            y.set(p+".protection",new ArrayList<>(t.protection));y.set(p+".chests",new ArrayList<>(t.chests));
        }
        try{y.save(dataFile);}catch(IOException ex){getLogger().severe("Could not save treasuries.yml: "+ex.getMessage());}
    }
    private void loadData(){
        if(!dataFile.exists())return;
        YamlConfiguration y=YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection root=y.getConfigurationSection("treasuries");if(root==null)return;
        for(String id:root.getKeys(false)){
            ConfigurationSection s=root.getConfigurationSection(id);if(s==null)continue;
            org.bukkit.World w=Bukkit.getWorld(s.getString("world","world"));if(w==null)continue;
            Location origin=new Location(w,s.getInt("x"),s.getInt("y"),s.getInt("z"));
            Treasury t=new Treasury(id,origin,s.getInt("width"),s.getInt("height"),s.getInt("length"));
            t.min=new Location(w,s.getInt("minx"),s.getInt("miny"),s.getInt("minz"));
            t.remaining=s.getInt("remaining");t.unlocked=s.getBoolean("unlocked");
            t.protection.addAll(s.getStringList("protection"));t.chests.addAll(s.getStringList("chests"));
            treasuries.put(id,t);for(String k:t.protection)blockIndex.put(k,id);
        }
    }
    @Override public boolean onCommand(CommandSender s,Command c,String label,String[] a){
        if(a.length==0||a[0].equalsIgnoreCase("help")){msg(s,"/at generate [schematic] | list | remove <id> | reload");return true;}
        if(!admin(s))return true;
        switch(a[0].toLowerCase()){
            case "generate" -> {if(a.length>1)getConfig().set("generation.schematic",a[1]);generate(s);}
            case "list" -> {msg(s,"Скарбниці: "+treasuries.size());for(Treasury t:treasuries.values())msg(s,t.id+" @ "+t.origin.getWorld().getName()+" "+t.origin.getBlockX()+","+t.origin.getBlockY()+","+t.origin.getBlockZ()+" | захист "+t.remaining);}
            case "remove" -> {if(a.length<2){msg(s,"Вкажи ID.");break;}removeTreasury(a[1],true);msg(s,"Скарбницю видалено (якщо ID існував).");}
            case "reload" -> {reloadConfig();msg(s,"Конфіг перезавантажено.");}
            default -> msg(s,"Невідома команда. /at help");
        }return true;
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){
        if(args.length==1)return Arrays.asList("help","generate","list","remove","reload");
        if(args.length==2&&args[0].equalsIgnoreCase("remove"))return new ArrayList<>(treasuries.keySet());
        return Collections.emptyList();
    }
    private static final class Treasury {
        final String id;final Location origin;Location min;final int width,height,length;
        final Set<String> protection=new HashSet<>(),chests=new HashSet<>();
        int remaining;boolean unlocked;
        Treasury(String id,Location origin,int w,int h,int l){this.id=id;this.origin=origin;this.min=origin.clone();width=w;height=h;length=l;}
    }
}
