# AquaTreasurys (Paper 1.21.11 / Java 21)

## Build
```bash
mvn -B clean package
```
JAR: `target/AquaTreasurys-1.0.0.jar`

Install WorldEdit and WorldGuard on the server, then place this plugin in `plugins/`.
Put `.schem` files in `plugins/AquaTreasurys/schematics/`.

## Important
This is a starter implementation project. Generation is disabled by default.
Set the world, schematic filename and generation limits in `config.yml`.
Protection blocks are configured by material. Loot chest names are configured using
the chest's custom inventory name (e.g. `AquaLoot`).
